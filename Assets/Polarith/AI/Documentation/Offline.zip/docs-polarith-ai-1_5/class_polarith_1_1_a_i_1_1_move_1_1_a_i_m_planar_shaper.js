var class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_planar_shaper =
[
    [ "PlanarSensor", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_planar_shaper_a066b8ccfbaeb09c97113fec01a770725.html#a066b8ccfbaeb09c97113fec01a770725", null ]
];